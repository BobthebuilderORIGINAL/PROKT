﻿using Microsoft.AspNetCore.Mvc;

namespace MyFirstWebApp2025.Controllers
{
    public class ArticleController : Controller
    {
        public IActionResult ById()
        {
            return View();
        }
    }
}
